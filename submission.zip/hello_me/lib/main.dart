import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/widgets.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

enum Status {
  Uninitialized,
  Guest,
  Authenticated,
  Authenticating,
  Unsuccessful
}

class UserRepository with ChangeNotifier {
  FirebaseAuth _auth;
  User _user;
  Status _status = Status.Uninitialized;
  String _currentUserEmail = "";

  UserRepository.instance() : _auth = FirebaseAuth.instance {
    _auth.authStateChanges().listen(_onAuthStateChanged);
  }

  Status get status => _status;
  User get user => _user;
  String get currentUserEmail => _currentUserEmail;

  Future<bool> signIn(String email, String password) async {
    try {
      _status = Status.Authenticating;
      //When Authenticating => change to loading bar
      notifyListeners();
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      _currentUserEmail = email;
      _updateCollection(email);
      _saved.clear();
      return true;
    } catch (e) {
      _status = Status.Unsuccessful;

      notifyListeners();
      return false;
    }
  }

  Future signOut() async {
    _auth.signOut();
    _status = Status.Guest;
    _currentUserEmail = "";
    //When Signing out => regular main screen. will be in OnPressed
    notifyListeners();
    return Future.delayed(Duration.zero);
  }

  Future<void> _onAuthStateChanged(User firebaseUser) async {
    if (firebaseUser == null) {
      _status = Status.Unsuccessful;
    } else {
      _user = firebaseUser;
      _status = Status.Authenticated;
      //When Authenticated => return to home page and put exit_to_app icon
    }
    notifyListeners();
  }
}

void _updateCollection(String currentUserEmail) {
  //Enter all the local saved to the cloud collection
  _saved.forEach((WordPair pair) {
    String docName = pair.asPascalCase;
    FirebaseFirestore.instance.collection(currentUserEmail).doc(docName).set({
    });
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(App());
}

class App extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initialization,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Scaffold(
              body: Center(
                  child: Text(snapshot.error.toString(),
                      textDirection: TextDirection.ltr)));
        }
        if (snapshot.connectionState == ConnectionState.done) {
          return MyApp();
        }
        return Center(child: CircularProgressIndicator());
      },
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
        create: (_) => UserRepository.instance(),
        child: Consumer(builder: (context, UserRepository user, _) {
          return MaterialApp(
            title: 'Startup Name Generator',
            theme: ThemeData(
              primaryColor: Colors.red,
            ),
            home: RandomWords(),
          );
        }));
  }
}

final TextStyle _biggerFont = const TextStyle(fontSize: 18); // NEW
final _saved = Set<WordPair>();

class RandomWords extends StatefulWidget {
  @override
  _RandomWordsState createState() => _RandomWordsState();
}

class _RandomWordsState extends State<RandomWords> {

  void _addOnePair(String currentUserEmail, WordPair pair) {
      String docName = pair.asPascalCase;
      FirebaseFirestore.instance.collection(currentUserEmail).doc(docName).set({
      });
  }

  void _removeOnePair(String currentUserEmail, WordPair pair) {
    String docName = pair.asPascalCase;
    FirebaseFirestore.instance..collection(currentUserEmail).doc(docName).delete();
  }

  final List<WordPair> _suggestions = <WordPair>[];

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserRepository>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Startup Name Generator'),
        actions: [
          IconButton(
              icon: Icon(Icons.favorite),
              onPressed: () {
                if (!(user.status == Status.Authenticated)) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => SavedSuggestionsPage()),
                  );
                } else {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => GetAllUserPairsRealtime()),
                  );
                }
              }),

//_RandomWordsState
          Consumer(
            builder: (context, UserRepository user, _) {
              switch (user.status) {
                case Status.Authenticated:
                  return IconButton(
                      icon: Icon(Icons.exit_to_app),
                      onPressed: () {
                        user.signOut();
                        _saved.clear();
                      });
                default:
                  return Builder(
                    builder: (context) => IconButton(
                        icon: Icon(Icons.login),
                        onPressed: () {
                          {
                            TextEditingController _email;
                            TextEditingController _password;

                            final _formKey = GlobalKey<FormState>();
                            final _key = GlobalKey<ScaffoldState>();

                            _email = TextEditingController(text: "");
                            _password = TextEditingController(text: "");

                            Navigator.of(context).push(
                              MaterialPageRoute<void>(
                                builder: (BuildContext context) {
                                  return Scaffold(
                                    key: _key,
                                    appBar: AppBar(
                                      title: Text('Login'),
                                    ),
                                    body: Form(
                                      key: _formKey,
                                      child: Padding(
                                          padding: const EdgeInsets.fromLTRB(12.0, 32.0, 8.0, 8.0),
                                          child:Column(
                                        children: <Widget>[
                                          Text(
                                              'Welcome to Startup Names Generator, please log in below\n\n',
                                              style: TextStyle(fontSize: 16)),
                                          TextFormField(
                                            controller: _email,
                                            validator: (value) =>
                                                (value.isEmpty)
                                                    ? "Please Enter Email"
                                                    : null,
                                            decoration: InputDecoration(
                                                prefixIcon: Icon(Icons.email),
                                                labelText: "Email",
                                                border: OutlineInputBorder()),
                                          ),
                                          Divider(),
                                          TextFormField(
                                            controller: _password,
                                            validator: (value) =>
                                                (value.isEmpty)
                                                    ? "Please Enter Password"
                                                    : null,
                                            decoration: InputDecoration(
                                                prefixIcon: Icon(Icons.lock),
                                                labelText: "Password",
                                                border: OutlineInputBorder()),
                                          ),
                                          user.status == Status.Authenticating
                                              ? Center(
                                                  child:
                                                      CircularProgressIndicator())
                                              : Padding(
                                                  padding: const EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 8.0),
                                                  child: Material(
                                                    elevation: 5.0,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            30.0),
                                                    color: Colors.red,
                                                    child: MaterialButton(
                                                      onPressed: () async {
                                                        if (_formKey
                                                            .currentState
                                                            .validate()) {
                                                          if (!await user
                                                              .signIn(
                                                                  _email.text,
                                                                  _password
                                                                      .text)) {
                                                            _key.currentState
                                                                .showSnackBar(
                                                                    SnackBar(
                                                              content: Text(
                                                                  "There was an error logging into the app"),
                                                            ));
                                                          } else {
                                                            Navigator.of(context).pop();
                                                          }
                                                        }
                                                      },
                                                      child: Text(
                                                        "                                    Log in                                        ",
                                                        style: TextStyle(
                                                            color:
                                                                Colors.white,
                                                            fontSize: 16),
                                                      ),
                                                    ),
                                                  ),
                                                ),

                                        ],
                                      )),
                                    ),
                                  );
                                }, // ...to here.
                              ),
                            );

                          }
                        }),
                  );
              }
            },
          ),
        ],
      ),
      body: _buildSuggestions(),
    );
  }

  Widget _buildSuggestions() {
    return ListView.builder(
        itemBuilder: (BuildContext _context, int i) {
          // Add a one-pixel-high divider widget before each row
          // in the ListView.
          if (i.isOdd) {
            return Divider();
          }
          final int index = i ~/ 2;
          // If you've reached the end of the available word
          if (index >= _suggestions.length) {
            // ...then generate 10 more and add them to the
            _suggestions.addAll(generateWordPairs().take(10));
          }
          return _buildRow(_suggestions[index]);
        });

  }

  Widget _buildRow(WordPair pair) {
    final alreadySaved = _saved.contains(pair); // NEW
    return ListTile(
      title: Text(
        pair.asPascalCase,
        style: _biggerFont,
      ),

      trailing: Icon(
        alreadySaved ? Icons.favorite : Icons.favorite_border,
        color: alreadySaved ? Colors.red : null,
      ),

      onTap: () {
        setState(() {
          final user2 = Provider.of<UserRepository>(context, listen: false);
          if (alreadySaved) {
            _saved.remove(pair);
            if (user2.status == Status.Authenticated) {
              _removeOnePair(user2.currentUserEmail, pair);
            }
          } else {
            _saved.add(pair);
            if (user2.status == Status.Authenticated) {
              _addOnePair(user2.currentUserEmail, pair);
            }
          }

        });
      }, // ... to here.
    );
  }
}

class SavedSuggestionsPage extends StatefulWidget {
  @override
  _SavedSuggestionsPageState createState() => _SavedSuggestionsPageState();
}

class _SavedSuggestionsPageState extends State<SavedSuggestionsPage> {
  @override
  Widget build(BuildContext context) {

    final tiles = _saved.map(
      (WordPair pair) {
        return Padding(
            padding: const EdgeInsets.fromLTRB(0, 8.0, 0, 8.0),
            child: ListTile(
          title: Text(
            pair.asPascalCase,
            style: _biggerFont,
          ),
          trailing: Builder(
            builder: (context) => IconButton(
              icon: Icon(Icons.delete_outline),
              onPressed: () {
                setState(() {
                  _saved.remove(pair);
                });
              },
            ),
          ),
        ));
      },
    );
    final divided = ListTile.divideTiles(
      context: context,
      tiles: tiles,
    ).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text('Saved Suggestions'),
      ),
      body: ListView(children: divided)
    );
  }
}

class GetAllUserPairsRealtime extends StatelessWidget {
  final FirebaseFirestore db = FirebaseFirestore.instance;

  Stream<List<QueryDocumentSnapshot>> _getAllUserPairs(
      String currentUserEmail) {
    return db.collection(currentUserEmail).snapshots().map(
        (value) => value.docs); // Map the query result to the list of documents
  }

  Future<void> _deletePairDoc(String currentUserEmail, String docIdToDelete) {
    return db.collection(currentUserEmail).doc(docIdToDelete).delete();
  }

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<UserRepository>(context);

    return StreamBuilder<List<QueryDocumentSnapshot>>(
      stream: _getAllUserPairs(user.currentUserEmail),
      builder: (context, AsyncSnapshot<List<QueryDocumentSnapshot>> snapshot) {
        if (snapshot.hasData) {
          final List<QueryDocumentSnapshot> data = snapshot.data;

          return Scaffold(
            appBar: AppBar(
              title: Text('Saved Suggestions'),
            ),
            body: ListView.separated(
                  padding: const EdgeInsets.fromLTRB(0, 8.0, 0, 8.0),
                  itemBuilder: (context, index) {
                    final docID = data[index].id;
                    return ListTile(
                      title: Text(
                          '$docID',
                        style: _biggerFont),
                      trailing: IconButton(
                        icon: Icon(Icons.delete_outline),
                        onPressed: () {
                          _deletePairDoc(user.currentUserEmail, docID);

                          WordPair pairToDelete;
                          _saved.forEach((WordPair pair) {
                            String currentPair = pair.asPascalCase;
                            if(currentPair==docID){
                              pairToDelete = pair;
                            }
                          });
                          if(pairToDelete!=null) {
                            _saved.remove(pairToDelete);
                          }

                        },
                      ),
                    );
                  },
                  separatorBuilder: (_, __) => Divider(),
                  itemCount: data.length),

          );
        }

        return Scaffold(
            body: Center( child:
        CircularProgressIndicator()));

      },
    );
  }
}
